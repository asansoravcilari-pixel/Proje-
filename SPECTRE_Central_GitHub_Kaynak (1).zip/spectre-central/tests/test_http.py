import json
import sys
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
import main
from core import Broker
from http.server import ThreadingHTTPServer

class APITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        main.TOKEN='c'*40;main.AGENTS={'node-a':'a'*40}
        main.broker=Broker(str(Path(cls.tmp.name)/'memory.sqlite3'),main.AGENTS)
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),main.Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join();main.broker.db.close();cls.tmp.cleanup()
    def post(self,path,data,token='c'*40):
        req=urllib.request.Request('http://127.0.0.1:'+str(self.server.server_port)+path,data=json.dumps(data).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=3) as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    def test_unauthorized(self):self.assertEqual(self.post('/health',{},'wrong')[0],401)
    def test_agent_cannot_propose_or_approve(self):
        for route in ['/plan','/approve','/screen']:
            self.assertEqual(self.post(route,{},'a'*40)[0],403)
    def test_text_round_trip(self):
        code,p=self.post('/plan',{'mode':'text','text':'/json {"kind":"home","target":"phone"}'})
        self.assertEqual(code,200)
        body={'id':p['id'],'digest':p['digest'],'mode':'text','confirmed':True}
        self.assertEqual(self.post('/approve',body)[1]['execute']['kind'],'home')
        self.assertEqual(self.post('/approve',body)[0],400)
    def test_voice_confirmation_is_exact(self):
        with patch.object(main,'transcribe',return_value='geri git'),patch.object(main,'plan',return_value={'kind':'back','target':'phone'}),patch.object(main,'speak',return_value='audio'):
            code,p=self.post('/plan',{'mode':'voice','audio':'mock'})
        self.assertEqual(code,200)
        with patch.object(main,'transcribe',return_value='onaylıyorum ama bekle'):
            result=self.post('/approve',{'mode':'voice','audio':'mock','id':p['id'],'digest':p['digest']})
        self.assertNotIn('execute',result[1])
    def test_voice_approve(self):
        p=main.broker.propose({'kind':'back','target':'phone'},'voice')
        with patch.object(main,'transcribe',return_value='Onaylıyorum.'):
            code,r=self.post('/approve',{'mode':'voice','audio':'mock','id':p['id'],'digest':p['digest']})
        self.assertEqual(code,200);self.assertEqual(r['execute']['kind'],'back')
    def test_tts_failure_does_not_leave_proposal(self):
        before=set(main.broker.pending)
        with patch.object(main,'transcribe',return_value='geri git'),patch.object(main,'plan',return_value={'kind':'back','target':'phone'}),patch.object(main,'speak',side_effect=RuntimeError):
            code,_=self.post('/plan',{'mode':'voice','audio':'mock'})
        self.assertEqual(code,400);self.assertEqual(set(main.broker.pending),before)

if __name__=='__main__':unittest.main()
