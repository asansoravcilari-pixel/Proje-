import importlib.util
import unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'agent'/'agent.py'
s=importlib.util.spec_from_file_location('remote_agent',p);agent=importlib.util.module_from_spec(s);s.loader.exec_module(agent)
class AgentTests(unittest.TestCase):
    def test_output_bounded_and_token_not_inherited(self):
        import os,json
        os.environ['CONTROL_TOKEN']='must-not-be-in-child'
        result=json.loads(agent.execute("printf '%s' \"${CONTROL_TOKEN-unset}\""))
        self.assertEqual(result['output'],'unset')
        result=json.loads(agent.execute("python3 -c 'print(\"x\"*20000)'"))
        self.assertEqual(len(result['output']),16000)
    def test_exit_code(self):
        import json
        self.assertEqual(json.loads(agent.execute('exit 7'))['exit_code'],7)
