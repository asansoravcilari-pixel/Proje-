import sys
import tempfile
import threading
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from core import Broker, validate

class ConsentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.now=100
        self.b=Broker(str(Path(self.tmp.name)/'memory.sqlite3'),['node-a'],lambda:self.now)
    def tearDown(self):
        self.b.db.close();self.tmp.cleanup()
    def plan(self,kind='back',mode='text',**kw):
        return self.b.propose(dict(kind=kind,target=kw.pop('target','phone'),**kw),mode)
    def approve(self,p,**kw):
        return self.b.approve(p['id'],kw.get('digest',p['digest']),kw.get('mode',p['mode']),kw.get('confirmed',True))
    def test_no_execution_at_proposal(self):
        self.plan('server_exec',target='node-a',command='pwd')
        self.assertEqual(self.b.claim('node-a'),{})
    def test_explicit_confirmation_required(self):
        p=self.plan()
        with self.assertRaises(ValueError):self.approve(p,confirmed=False)
    def test_voice_cannot_use_text_confirmation(self):
        p=self.plan(mode='voice')
        with self.assertRaises(ValueError):self.approve(p,mode='text')
    def test_text_cannot_use_voice_confirmation(self):
        p=self.plan()
        with self.assertRaises(ValueError):self.approve(p,mode='voice')
    def test_digest_binds_exact_action(self):
        p=self.plan()
        with self.assertRaises(ValueError):self.approve(p,digest='changed')
    def test_replay_rejected(self):
        p=self.plan();self.assertEqual(self.approve(p)['execute']['kind'],'back')
        with self.assertRaises(ValueError):self.approve(p)
    def test_expired(self):
        p=self.plan();self.now+=121
        with self.assertRaises(ValueError):self.approve(p)
    def test_cancel(self):
        p=self.plan();self.b.cancel(p['id'])
        with self.assertRaises(ValueError):self.approve(p)
    def test_concurrent_approval_only_once(self):
        p=self.plan();results=[]
        def act():
            try:self.approve(p);results.append(True)
            except ValueError:results.append(False)
        threads=[threading.Thread(target=act) for _ in range(8)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertEqual(sum(results),1)
    def test_memory_only_after_consent_and_persists(self):
        p=self.plan('remember',target='central',key='name',value='SPECTRE')
        self.assertEqual(self.b.db.execute('SELECT count(*) FROM memory').fetchone()[0],0)
        self.approve(p)
        other=Broker(str(Path(self.tmp.name)/'memory.sqlite3'))
        self.assertEqual(other.db.execute('SELECT value FROM memory').fetchone()[0],'SPECTRE');other.db.close()
    def test_memory_recall_forget(self):
        self.approve(self.plan('remember',target='central',key='k',value='v'))
        self.assertEqual(self.approve(self.plan('recall',target='central',key='k'))['result'],'v')
        self.approve(self.plan('forget',target='central',key='k'))
        self.assertEqual(self.approve(self.plan('recall',target='central',key='k'))['result'],'Kayıt yok')
    def test_agent_target_and_at_most_once_claim(self):
        p=self.plan('server_exec',target='node-a',command='pwd');self.approve(p)
        self.assertEqual(self.b.claim('other'),{})
        self.assertEqual(self.b.claim('node-a')['id'],p['id'])
        self.assertEqual(self.b.claim('node-a'),{})
        with self.assertRaises(ValueError):self.b.result('other',p['id'],'bad')
        self.b.result('node-a',p['id'],'ok')
        self.assertEqual(self.b.status(p['id'])['result'],'ok')
    def test_context_requires_once_only_screen_ticket(self):
        with self.assertRaises(ValueError):self.b.screen('made-up','screen')
        receipt=self.approve(self.plan('read_screen'))
        self.b.screen(receipt['screen_ticket'],'screen')
        with self.assertRaises(ValueError):self.b.screen(receipt['screen_ticket'],'again')
        self.assertEqual(self.b.take_screen(),'screen');self.assertEqual(self.b.take_screen(),'')
    def test_context_expires(self):
        receipt=self.approve(self.plan('read_screen'));self.b.screen(receipt['screen_ticket'],'screen');self.now+=121
        self.assertEqual(self.b.take_screen(),'')
    def test_invalid_coordinates_and_unregistered_target(self):
        for action in [dict(kind='tap',target='phone',x=-1,y=.3),dict(kind='server_exec',target='other',command='pwd'),dict(kind='home',target='phone',hidden='x'),dict(kind='remember',target='phone',key='x',value='y')]:
            with self.assertRaises(ValueError):validate(action,{'node-a'})
    def test_restart_drops_pending_and_jobs(self):
        self.plan();other=Broker(str(Path(self.tmp.name)/'memory.sqlite3'))
        self.assertEqual(other.pending,{});self.assertEqual(other.jobs,{});other.db.close()

if __name__=='__main__':unittest.main()
