"""Single-user, explicit-consent broker. No transcript or audit files."""
import hashlib
import json
import secrets
import sqlite3
import threading
import time

PHONE_ACTIONS = {'open_app', 'tap', 'type_text', 'swipe', 'back', 'home', 'read_screen'}
MEMORY_ACTIONS = {'remember', 'forget', 'recall'}
ALL_ACTIONS = PHONE_ACTIONS | MEMORY_ACTIONS | {'server_exec'}


def validate(action, agents):
    if not isinstance(action, dict):
        raise ValueError('İşlem nesne olmalı')
    kind = action.get('kind')
    target = action.get('target', 'phone')
    if kind not in ALL_ACTIONS:
        raise ValueError('Desteklenmeyen işlem')
    if kind in PHONE_ACTIONS and target != 'phone':
        raise ValueError('Telefon hedefi gerekli')
    if kind in MEMORY_ACTIONS and target != 'central':
        raise ValueError('Hafıza yalnız merkezde')
    if kind == 'server_exec' and target not in agents:
        raise ValueError('Tanımlı sunucu hedefi gerekli')
    allowed = {'kind', 'target'}
    fields = {'open_app': ['package'], 'tap': ['x', 'y'], 'type_text': ['text'],
              'swipe': ['x', 'y', 'x2', 'y2'], 'remember': ['key', 'value'],
              'forget': ['key'], 'recall': ['key'], 'server_exec': ['command']}.get(kind, [])
    allowed.update(fields)
    if set(action) - allowed:
        raise ValueError('Beklenmeyen işlem alanı')
    result = {'kind': kind, 'target': target}
    for field in fields:
        value = action.get(field)
        if field in {'x', 'y', 'x2', 'y2'}:
            if type(value) not in (float, int) or not 0 <= value <= 1:
                raise ValueError('Koordinatlar 0–1 arası olmalı')
        elif not isinstance(value, str) or not value or len(value) > 8000:
            raise ValueError('Eksik veya uzun metin: ' + field)
        result[field] = value
    return result


def summary(action):
    # Approval text is generated from validated data, never an LLM summary.
    k = action['kind']
    labels = {'open_app': 'Uygulamayı aç', 'tap': 'Ekrana dokun', 'swipe': 'Ekranı kaydır',
              'type_text': 'Odaktaki alana yaz', 'back': 'Geri git', 'home': 'Ana ekrana git',
              'read_screen': 'Ekran metnini oku ve merkeze gönder', 'remember': 'Özel hafızaya kaydet',
              'forget': 'Özel hafızadan sil', 'recall': 'Özel hafızadan oku',
              'server_exec': 'Sunucuda kabuk komutu çalıştır'}
    return labels[k] + '\nHedef: ' + action['target'] + '\n' + '\n'.join(
        f'{key}: {value}' for key, value in action.items() if key not in {'kind', 'target'})


class Broker:
    def __init__(self, memory_path, agents=(), clock=time.monotonic):
        self.db = sqlite3.connect(memory_path, check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=DELETE')
        self.db.execute('CREATE TABLE IF NOT EXISTS memory (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        self.db.commit()
        self.agents = set(agents)
        self.clock = clock
        self.lock = threading.RLock()
        self.pending = {}
        self.jobs = {}
        self.screen_tickets = {}
        self.screen_context = None

    def purge(self):
        now = self.clock()
        self.pending = {k: v for k, v in self.pending.items() if v['expires'] > now}
        self.jobs = {k: v for k, v in self.jobs.items() if v['expires'] > now}
        self.screen_tickets = {k:v for k,v in self.screen_tickets.items() if v > now}
        if self.screen_context and self.screen_context[0] <= now:
            self.screen_context = None

    def propose(self, action, mode):
        if mode not in ('text', 'voice'):
            raise ValueError('Geçersiz onay türü')
        action = validate(action, self.agents)
        with self.lock:
            self.purge()
            if len(self.pending) >= 32:
                raise ValueError('Önce bekleyen işlemleri iptal edin')
            ident = secrets.token_urlsafe(24)
            digest = hashlib.sha256(json.dumps(action, sort_keys=True).encode()).hexdigest()
            self.pending[ident] = dict(action=action, mode=mode, digest=digest, expires=self.clock()+120)
            return dict(id=ident, digest=digest, mode=mode, summary=summary(action), action=action, ttl=120)

    def cancel(self, ident):
        with self.lock:
            self.pending.pop(ident, None)
        return {'cancelled': True}

    def approve(self, ident, digest, mode, confirmed):
        with self.lock:
            self.purge()
            p = self.pending.get(ident)
            if not p or p['digest'] != digest or p['mode'] != mode or confirmed is not True:
                raise ValueError('Onay geçersiz, süresi dolmuş veya türü farklı')
            action = self.pending.pop(ident)['action']
            k = action['kind']
            if k in MEMORY_ACTIONS:
                if k == 'remember':
                    self.db.execute('INSERT OR REPLACE INTO memory VALUES (?, ?)', (action['key'], action['value']))
                    self.db.commit()
                    result = 'Kaydedildi'
                elif k == 'forget':
                    self.db.execute('DELETE FROM memory WHERE key=?', (action['key'],))
                    self.db.commit()
                    result = 'Silindi'
                else:
                    row = self.db.execute('SELECT value FROM memory WHERE key=?', (action['key'],)).fetchone()
                    result = row[0] if row else 'Kayıt yok'
                return {'result': result}
            if k == 'server_exec':
                self.jobs[ident] = dict(action=action, expires=self.clock()+120, state='queued', result=None)
                return {'job_id': ident, 'result': 'Onaylandı; ajan bekleniyor'}
            if k == 'read_screen':
                ticket = secrets.token_urlsafe(24)
                self.screen_tickets[ticket] = self.clock()+30
                return {'execute': action, 'screen_ticket': ticket}
            return {'execute': action}

    def claim(self, target):
        with self.lock:
            self.purge()
            for ident, job in self.jobs.items():
                if job['action']['target'] == target and job['state'] == 'queued':
                    job['state'] = 'claimed'  # no automatic retry, avoids duplicate side effects
                    return {'id': ident, 'action': job['action']}
        return {}

    def result(self, target, ident, result):
        with self.lock:
            self.purge()
            job = self.jobs.get(ident)
            if not job or job['action']['target'] != target or job['state'] != 'claimed':
                raise ValueError('Geçersiz iş sonucu')
            job['result'] = str(result)[:16000]
            job['state'] = 'done'
        return {'ok': True}

    def status(self, ident):
        with self.lock:
            self.purge()
            job = self.jobs.get(ident)
            if not job:
                raise ValueError('İş bulunamadı/süresi doldu; otomatik tekrar yok')
            return {'state': job['state'], 'result': job['result']}

    def screen(self, ticket, text):
        with self.lock:
            self.purge()
            if ticket not in self.screen_tickets or not isinstance(text,str) or len(text)>16000:
                raise ValueError('Ekran okuma onayı geçersiz')
            del self.screen_tickets[ticket]
            self.screen_context = (self.clock()+120, text)
            return {'ok': True}

    def take_screen(self):
        with self.lock:
            self.purge()
            value = self.screen_context
            self.screen_context = None
            return value[1] if value else ''
