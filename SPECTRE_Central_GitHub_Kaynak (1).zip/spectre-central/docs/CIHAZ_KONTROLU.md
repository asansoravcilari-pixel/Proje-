# Gerçek cihaz kabul kontrolü

Bu kontroller henüz çalıştırılmadı. Yalnız kendi test cihazınızda uygulayın.

- [ ] GitHub Actions'ta Python testleri, assembleDebug ve lintDebug başarılı.
- [ ] Debug APK kuruluyor; SPECTRE erişilebilirlik izni ve mikrofon izni açıkça isteniyor.
- [ ] Yanlış token/HTTPS sertifikası bağlantıyı reddediyor.
- [ ] Model olmadan `/json` ile ana ekran önerisi geliyor; onaydan önce telefon hareket etmiyor.
- [ ] Yazılı komutta yazılı onay var; sesli komutta yazılı onay yok.
- [ ] Sesli öneri bütünüyle çalınıyor; çalma sırasında mikrofon kapalı.
- [ ] “Onaylıyorum” bir kere çalıştırıyor; “hayır”, “iptal”, “onaylıyorum ama bekle” çalıştırmıyor.
- [ ] Ses kaydı 30 saniyeyi aşmıyor; ses iptali yeni isteğe karışmıyor.
- [ ] 120 saniye geçtikten sonra hiçbir işlem gerçekleşmiyor.
- [ ] Başka uygulamada dokunma/kaydırma hedefi kontrol paneli değil doğru ekran.
- [ ] Ekran okuma öncesi veri gönderilmiyor; okuma onayı sonrası parola alanları atlanıyor.
- [ ] Ana sunucu yeniden başladığında yalnız açıkça kaydedilen hafıza kalıyor; eski onaylar geçersiz.
- [ ] Ajan yanlış hedefte komut almıyor; bağlantı kesilince aynı komut otomatik tekrar etmiyor.
- [ ] Bildirimden durdurunca mikrofon/panel kapanıyor; eski ağ yanıtı telefon işlemi yapmıyor.
- [ ] Uygulama tekrar açıldığında komut/ses/anahtar geçmişi geri gelmiyor.

Yalnız onaylandıktan sonra başlayan sunucu komutunun, telefondaki bağlantı kesilince geri alınmadığını özellikle doğrulayın.
