# SPECTRE Central — GitHub'da APK derlenecek kaynak paketi

Bu paket burada hazırlanmış **0.1 kaynak uygulamasıdır; derlenmiş APK değildir**. Telefonunuza veya sunucularınıza hiçbir şey kurulmadı. GitHub'a yükleme/push yapılmadı. ZIP, Android kaynakları, merkez API, Linux bağlantı ajanı, onay testleri ve GitHub Actions iş akışını içerir.

Bu, bu sohbette belirlenen tek merkezli asistan için ayrı, küçük bir native Android istemcisidir. Önceki SPECTRE Duo Flutter/SSH/SFTP projesinin güncellemesi değildir; onun kaynaklarını değiştirmez veya içeriyormuş gibi sunmaz.

## GitHub'da APK derleme — telefondan da yapılabilir

1. ZIP'i açın. İçindeki `spectre-central` klasörünün **içeriğini** yeni GitHub deponuzun köküne yükleyin. `settings.gradle`, `app`, `server`, `tests` ve `.github` aynı kökte bulunmalı. ZIP dosyasını tek başına yüklemek derleme başlatmaz.
2. Dosya yöneticinizde **gizli dosyaları gösterin**. `.github/workflows/android.yml` mutlaka depoda olmalı. Mobil yükleyici gizli klasörü almıyorsa GitHub → Add file → Create new file ile bu tam yolu oluşturup dosyadaki metni yapıştırın.
3. Deponun Actions bölümünü açın → **APK derle** → **Run workflow**. `main` veya `master` dalına push da tetikler.
4. Başarılı işin Artifacts bölümünden `SPECTRE-Central-debug-APK` indirin. İndirdiğiniz artifact ZIP'inin içinde `app-debug.apk` bulunur.
5. Bu otomatik debug imzalı test APK'sıdır. Release keystore gerekmez. Üretim imzası/Play Store yayını bu pakette yoktur. Ayrı CI çalışmaları farklı debug imzası üretebilir; eski debug uygulamasının üstüne kurulum reddedilirse eski test APK'sını kaldırmak veya sabit imzalama anahtarıyla ayrı release akışı hazırlamak gerekir.

Derleme zinciri: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compile/target SDK 35, min SDK 26 (Android 8+). Wrapper JAR gerekmez; Actions sabit Gradle sürümünü kurar. Bilgisayarda aynı sürümle `gradle :app:assembleDebug :app:lintDebug` çalıştırılabilir. Actions internetten Android/Gradle bağımlılıklarını indirir; sunucunuzu yapılandırmaz.

## Mimari ve özel hafıza

- **Ana sunucu:** karar/plan üretimi (yerel Ollama API), ses çözümleme (faster-whisper), Türkçe ses üretimi (espeak-ng), onay yönetimi ve SQLite özel hafıza. Hepsi aynı fiziksel sunucuda tutulabilir.
- **Telefon:** küçük kontrol paneli, mikrofon PCM yakalama, sunucudan gelen WAV sesi çalma, erişilebilirlik üzerinden onaylı ekran işlemleri. Yerel AI/STT/TTS modeli yoktur.
- **Diğer Linux sunucuları:** `agent/agent.py` yalnız merkeze HTTPS ile dışarı bağlantı kurar. Her ajanın ayrı anahtarı ve hedef adı vardır. Sunucuya dışarıdan açık bir ajan portu gerekmez.
- **Kalıcı özel hafıza:** yalnız ana sunucudaki `private-memory.sqlite3`. Otomatik sohbet kaydı değildir: `remember`, `recall`, `forget` işlemleri ayrı onay ister. Model geçmiş konuşmaları kendiliğinden hatırlamaz; istenen anahtar açıkça okunur.
- Anahtarlar, bekleyen onaylar, ses parçaları, ekran metni ve kısa süreli sonuçlar çalışırken geçici RAM kullanır. Bu zorunlu çalışma belleğidir; RAM'e kalıcı kayıt sistemi kurulmamıştır. Merkezi onay/sonuç nesneleri en fazla 120 saniyelik geçerliliğe sahiptir; sonraki API işlemlerinde temizlenir veya süreç kapanınca kaybolur.
- Telefonda SharedPreferences, SQLite, ses dosyası, sohbet dosyası, analitik veya uygulama log dosyası oluşturulmaz. Sunucu erişim logu kapalıdır; örnek Docker yapılandırması container logunu da kapatır. SQLite kendi işlem günlüğünü geçici oluşturabilir; bu özel hafızanın tutarlılık mekanizmasıdır, sohbet günlüğü değildir.
- İşletim sistemi, klavye, reverse proxy, Ollama veya çalıştırılan kullanıcı komutlarının kendi günlükleri/swap/crash dump davranışları ayrı yapılandırmadır. Uygulama bunlar adına sıfır iz garantisi vermez. Kaydedilmesini onayladığınız veriler, program/model dosyaları ve bağlantı yapılandırması disk alanı gerektirir. SQLite uygulama seviyesinde şifrelenmemiştir; disk/volume şifrelemesi sunucu yöneticisine aittir.

## Yazılı ve sesli onay

1. Yazılı veya sesli komut merkeze gider; model yalnız **tek adım** önerir.
2. Merkez türü/hedefi/alanları doğrular. Onay metni modelin özetinden değil gerçek işlem alanlarından üretilir.
3. Yazılı komut: işlem gösterilir; **Bu işlemi onaylıyorum** düğmesiyle onaylanır.
4. Sesli komut: işlem merkezde seslendirilip telefonda çalınır. Çalma bitmeden onay mikrofonu açılmaz. **Sesli onay / iptal söyle** düğmesine basıp `onaylıyorum` deyin, sonra konuşmayı bitirin. Başka tanınan metin iptaldir. Yazılı onay düğmesi bu akışta gösterilmez.
5. Onay işlem kimliğine, işlem özetine, giriş türüne ve 120 saniyelik süreye bağlıdır; bir kez tüketilir. Sunucu ajanı kendi kendine onay veremez.
6. Onaydan önce bağlantı giderse işlem başlamaz. Onay merkeze ulaştıktan sonra bağlantının kesilmesi, başlamış komutu geri almaz. Belirsiz ağ hatasında **otomatik tekrar yapılmaz**. Sonucu kontrol edin; aynı komutu düşünmeden yeniden göndermeyin.

Sesli onay bir biyometrik kimlik doğrulama sistemi değildir. Mikrofondaki başka bir kişinin veya oynatılan sesin `onaylıyorum` demesi de tanınabilir. TTS sırasında dinleme kapatılarak kendi yanıtının onay sayılması önlenir. Kontrol token'ını paylaşmayın.

## Uygulamadaki işlemler

| İşlem | Destek |
|---|---|
| Paket adıyla uygulama aç | `open_app` |
| Ekrana dokun/kaydır | `tap`, `swipe`; 0–1 normalize ekran koordinatları |
| Odaktaki alana yaz | `type_text`; alan metnini değiştirir, otomatik Gönder'e basmaz |
| Geri / ana ekran | `back`, `home` |
| Talep üzerine ekran metni oku | `read_screen`; erişilebilirlik ağacı, parola alanları atlanır |
| Özel hafızaya yaz/oku/sil | `remember`, `recall`, `forget` |
| Diğer Linux sunucusunda kabuk komutu | `server_exec`; tam komut onay ekranında görünür |

`read_screen` ayrı onay sonrası metni merkeze gönderir. Metin 120 saniye içinde bir sonraki plan isteğine bir kez bağlanır; SQLite'a kaydedilmez. Ekran içeriği modele güvenilmeyen veri olarak işaretlenir. Ekran içindeki her türlü hassas bilginin otomatik sansürleneceği garanti edilmez; okuma iznini buna göre verin.

Bu sürümde sürekli uyandırma kelimesi, otomatik ardışık çok adımlı çalışma, ekran görüntüsü/kamera vision, telefon root kabuğu, Windows ajanı, iki SSH terminali ve SFTP arayüzü yoktur. Telefon rootlu olabilir, ancak istemci `su` çalıştırmaz. Oyun/canvas ekranlarında metin bulunmayabilir. Android'in korumalı ekranları ve uygulama kısıtları aşılmaz. “Her uygulamada her şeyi yapar” garantisi yoktur. Sesli komut ve onay **bas-konuş** biçimindedir; eller serbest sürekli dinleme değildir.

## Ana sunucu hazırlama — sizin uygulayacağınız adımlar

Bu bölüm komut tarifi verir; hazırlanırken çalıştırılmadı.

Gerekenler: Python 3.12 veya Docker, sunucuda mevcut Ollama ve bir model, yerel faster-whisper model klasörü, espeak-ng, telefondan erişilen geçerli sertifikalı HTTPS adresi. GPU zorunlu değildir; hız sunucuya/model boyutuna bağlıdır. Türkçe espeak sesi robotik olabilir.

1. `server/requirements.txt` bağımlılıklarını kendi sanal ortamınıza kurun. Debian/Ubuntu'da `espeak-ng` paketini sistem yöneticisi kurabilir.
2. faster-whisper uyumlu model ağırlıklarını örneğin `models/whisper/` içine önceden yerleştirin (CTranslate2 model dosyaları ve tokenizer/config dahil). Başlangıçta indirilecek model yoktur; `local_files_only=True` kullanılır. Bu pakete büyük model ağırlıkları dahil değildir.
3. Ana sunucuda her biri ayrı iki anahtar üretin: `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`. Gerçek anahtarları GitHub'a yüklemeyin. `.env.example` değerlerini kendi sunucunuzdaki `.env` dosyasında değiştirin; dosya izinlerini yalnız servis hesabına verin.
4. `CONTROL_TOKEN` telefon içindir. `AGENT_TOKENS` JSON eşlemesindeki `node-a` hedef adı, o sunucunun `AGENT_TOKEN` değeriyle eşleşmeli. Başka ajan istemiyorsanız `{}` kullanın.
5. `OLLAMA_MODEL` sunucunuzda zaten bulunan model adı olmalı. Kullanılabilir modeliniz JSON/tool planlarını yeterince iyi üretebilmeli. Model değiştirmek yalnız yapılandırmadır.
6. Docker'sız çalıştırırken `OLLAMA_URL`, `WHISPER_MODEL_PATH`, `MEMORY_PATH`, `CONTROL_TOKEN`, `AGENT_TOKENS`, `OLLAMA_MODEL` ortam değişkenlerini servisinizde tanımlayın ve `python3 -B server/main.py` çalıştırın. Dış arayüzdeki 8080 portunu internete açmayın; yalnız HTTPS reverse proxy erişsin.
7. Docker tercih ederseniz `compose.yaml` başlangıç örneğidir. `docker compose up --build` komutunu **siz** çalıştırırsınız. Örnek merkez API'sini host üzerinde yalnız `127.0.0.1:8080` portuna bağlar. Ollama'nın container'dan erişilebildiğini doğrulayın; yalnız localhost'ta dinleyen host Ollama'sına bridge üzerinden erişilemeyebilir. Docker bridge arayüzü için güvenli bind/firewall ayarı veya mevcut özel container ağı gerekebilir. Ollama'yı halka açık kimlik doğrulamasız portla yayınlamayın.
8. `docs/Caddyfile.example` HTTPS reverse proxy örneğidir. Alan adını size ait DNS kaydıyla değiştirin. APK yalnız HTTPS kabul eder; self-signed sertifika güveni otomatik kabul edilmez.

Sunucu token kontrolü HTTP başlığında Bearer biçimindedir. Merkezi servis tek kullanıcı/tek güvenilen aktif telefon oturumu için tasarlanmıştır; çok kullanıcılı tenant ayrımı yoktur. Anahtarları bilen kişi o rolün erişimine sahiptir. İnternet üzerinde üretim kullanımı öncesi kaynak limiti, ağ erişimi ve gerçek cihaz testlerini yapın.

## Diğer sunucudaki ajan

Yalnız sizin yönettiğiniz Linux sunucusunda, ayrı servis hesabında:

```bash
export CENTRAL_URL='https://asistan.example.com'
# AGENT_TOKEN değerini kendi güvenli servis ortamınıza koyun; depoya yazmayın.
python3 -B agent/agent.py
```

Ajan merkezi 2 saniyede bir sorgular; onaylanmış işi bir kere alır. `/bin/sh -c` ile tam onaylı komutu o servis hesabının yetkileriyle çalıştırır. Ajan normalde root olarak başlatılmamalı; ayrıcalıklı komut gereksinimini sizin servis yetkiniz belirler. Komut hedef sunucuda dosya oluşturabilir/değiştirebilir; bunlar onayladığınız işlemin sonucudur, asistanın arka plan geçmiş kaydı değildir.

Komut süresi 60 saniye, çıktı 16 KB ile sınırlandırılmıştır; uzun işler için kodun süre/çıktı politikasını bilinçli değiştirmeniz gerekir. Ajan API anahtarlarını komutun ortamına aktarmaz. İş alındıktan sonra ajan çökerse otomatik yeniden çalıştırılmaz; sonuç belirsiz kalabilir. `Sunucu sonucunu kontrol et` düğmesi kısa süreli merkezi sonucu gösterir. Sunucu tarafındaki komutu durdurma/geri alma düğmesi bu sürümde yoktur.

## APK ilk açılış

1. `Erişilebilirlik ayarlarını aç` ile SPECTRE hizmetini kendiniz etkinleştirin. Sideload edilen uygulamalarda Android ayrıca kısıtlı ayarlara izin vermenizi isteyebilir; cihaz sürümüne göre menü değişir.
2. HTTPS adresini ve kontrol anahtarını yazın. Mikrofon iznini verin; gerekirse `Oturumu başlat` düğmesine tekrar basın.
3. Oturum boyunca görünür Android bildirimi ve SPECTRE kontrol balonu bulunur. Mikrofon yalnız ses düğmesine basınca açılır. Başlangıçta otomatik bağlanma/boot receiver yoktur.
4. Balondan komut panelini açın. Başka uygulamada işlem yapılırken panel geçici kaldırılır; işlem sonucu panelde gösterilir.
5. Bildirimden veya ana ekrandan durdurun. Yeniden açıldığında bağlantı/token tekrar girilir. Telefon üreticisinin pil yönetimi hizmeti kesebilir; gerçek cihaz davranışı test edilmelidir.

## Model olmadan bağlantı/işlem örnekleri

Yazı alanına bu komutlardan birini girin; **hepsi yine ayrı onay ister**:

```text
/json {"kind":"home","target":"phone"}
/json {"kind":"open_app","target":"phone","package":"com.android.settings"}
/json {"kind":"read_screen","target":"phone"}
/json {"kind":"tap","target":"phone","x":0.5,"y":0.5}
/json {"kind":"type_text","target":"phone","text":"Merhaba"}
/json {"kind":"remember","target":"central","key":"hitap","value":"SPECTRE"}
/json {"kind":"recall","target":"central","key":"hitap"}
/json {"kind":"server_exec","target":"node-a","command":"pwd"}
```

Doğal dil örnekleri: “Ana ekrana dön”, “Özel hafızana hitap anahtarıyla SPECTRE yaz”, “node-a sunucusunda pwd komutunu çalıştır”. Modelin önerisini okuyun/dinleyin; farklı veya eksikse iptal edin. Birden çok adımlı istekler tek seferde otomatik tamamlanmaz; her adım ayrı komut ve onaydır.

## Doğrulama durumu

- Burada Python standart kütüphanesiyle **24 test geçti**: açık onay, tür eşleşmesi, zaman aşımı, tekrar kullanma, eşzamanlı onay, hafıza kalıcılığı, ajan hedefi/rolü, bir kez teslim, sesli onay API akışı ve TTS hatasında iptal dahil.
- Ses testlerinde STT/TTS sonuçları taklit edildi. Gerçek Türkçe konuşma doğruluğu ve sunucu model performansı ölçülmedi.
- Android SDK/Gradle derleyicisi bu ortamda yok: **APK derlenmedi, Android lint ve fiziksel cihaz testi yapılmadı**. GitHub iş akışı test → assembleDebug → lintDebug adımlarını çalıştıracak; bu teslim iş akışının başarıyla tamamlandığını iddia etmez.
- Docker imajı ve canlı ajan bağlantısı kurulmadı/çalıştırılmadı. Sunucu işletim sistemi/HTTPS/model hazırlığı size aittir.
- `docs/CIHAZ_KONTROLU.md` ilk kurulum sonrası kabul kontrol listesidir.

## Dosyalar

`app/` Android istemcisi · `server/` merkez API/onay/özel hafıza · `agent/` Linux ajanı · `tests/` yerel Python testleri · `.github/workflows/android.yml` APK derleme · `compose.yaml` isteğe bağlı merkez container tarifi.
