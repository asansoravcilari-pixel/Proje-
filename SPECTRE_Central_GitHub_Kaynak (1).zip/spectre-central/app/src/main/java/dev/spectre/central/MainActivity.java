package dev.spectre.central;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText url, token;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,64,24,24);
        TextView title=new TextView(this); title.setText("SPECTRE\nMerkez bağlantısı"); title.setTextSize(27); root.addView(title);
        TextView info=new TextView(this); info.setText("Bağlantı bilgileri yalnız oturum boyunca bellekte tutulur. Komut paneli erişilebilirlik izniyle diğer uygulamaların üzerinde açılır."); root.addView(info);
        url=new EditText(this); url.setHint("https://asistan.example.com"); url.setSingleLine(true); url.setSaveEnabled(false); root.addView(url);
        token=new EditText(this); token.setHint("Kontrol anahtarı"); token.setInputType(129); token.setSaveEnabled(false); root.addView(token);
        if(Build.VERSION.SDK_INT>=26) { url.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO); token.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO); }
        Button access=new Button(this); access.setText("Erişilebilirlik ayarlarını aç"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access);
        Button start=new Button(this); start.setText("Oturumu başlat"); start.setOnClickListener(v->begin()); root.addView(start);
        Button stop=new Button(this); stop.setText("Durdur ve oturumu temizle"); stop.setOnClickListener(v->{stopService(new Intent(this,SessionService.class)); Session.stop(); if(ScreenService.instance!=null) ScreenService.instance.hide(); token.setText(""); status.setText("Durduruldu");}); root.addView(stop);
        status=new TextView(this); root.addView(status); setContentView(root);
    }
    private void begin() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},1); status.setText("İzin verdikten sonra Oturumu başlat'a tekrar basın."); return;
        }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2);
        String endpoint=url.getText().toString().trim().replaceAll("/+$", "");
        try { java.net.URI u=new java.net.URI(endpoint); if(!"https".equals(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null) throw new Exception(); }
        catch(Exception e) {status.setText("Geçerli HTTPS adresi girin"); return;}
        if(token.getText().length()<32) { status.setText("Kontrol anahtarı en az 32 karakter olmalı"); return; }
        if(ScreenService.instance==null) {status.setText("Önce SPECTRE erişilebilirlik hizmetini etkinleştirin"); return;}
        Session.stop(); Session.url=endpoint; Session.token=token.getText().toString(); Session.active=true;
        startForegroundService(new Intent(this,SessionService.class));
        ScreenService.instance.show(); status.setText("Oturum açık. Komut balonunu kullanın. Mikrofon yalnız Ses düğmesine bastığınızda açılır.");
        token.setText("");
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.clear(); }
}
