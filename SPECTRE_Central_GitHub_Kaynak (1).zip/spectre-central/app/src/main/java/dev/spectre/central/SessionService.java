package dev.spectre.central;
import android.app.*;
import android.content.*;
import android.os.*;
import android.content.pm.ServiceInfo;

public class SessionService extends Service {
    @Override public int onStartCommand(Intent i,int flags,int startId) {
        if(i!=null && "stop".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(!Session.active) { stopSelf(); return START_NOT_STICKY; }
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("session","Asistan oturumu",NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,SessionService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,"session").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("SPECTRE oturumu açık").setContentText("Mikrofon yalnız düğmeyle açılır; durdurmak için dokunun.")
            .setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"Durdur",stop).build()).build();
        if(Build.VERSION.SDK_INT>=29) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); else startForeground(7,n);
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() { Session.stop(); if(ScreenService.instance!=null) ScreenService.instance.hide(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) {return null;}
}
