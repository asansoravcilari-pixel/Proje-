package dev.spectre.central;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import org.json.JSONObject;
import java.util.function.Consumer;

public class ScreenService extends AccessibilityService {
    static ScreenService instance;
    private WindowManager wm;
    private View overlay;
    private Panel panel;
    private final Handler main=new Handler(Looper.getMainLooper());
    @Override public void onServiceConnected() {instance=this; wm=getSystemService(WindowManager.class);}
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {} // No continuous reading/storage.
    @Override public void onInterrupt() { hide(); }
    @Override public void onDestroy() {hide(); instance=null; Session.stop(); super.onDestroy();}
    void hide() { if(panel!=null) { panel.close(); panel=null; } remove(); }
    private void remove() { if(overlay!=null) {try {wm.removeView(overlay);}catch(Exception ignored){} overlay=null;} }
    void show() {
        hide(); if(!Session.active) return;
        Button bubble=new Button(this); bubble.setText("SPECTRE"); bubble.setOnClickListener(v->expand());
        add(bubble,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
    }
    private void add(View view,int width,int height,int flags) {
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags|WindowManager.LayoutParams.FLAG_SECURE,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END; lp.y=100;
        overlay=view; wm.addView(view,lp);
    }
    private void expand() {
        remove(); panel=new Panel(this,this);
        add(panel,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,0);
    }
    void execute(JSONObject a,Consumer<String> done) {
        remove(); // Do not click the confirmation overlay itself.
        main.postDelayed(()->{
            try {
                if(!Session.active) throw new Exception("Oturum durduruldu");
                String kind=a.getString("kind");
                if(kind.equals("open_app")) {
                    Intent launch=getPackageManager().getLaunchIntentForPackage(a.getString("package"));
                    if(launch==null) throw new Exception("Uygulama bulunamadı");
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); finish(done,"Uygulama açıldı");
                } else if(kind.equals("back")||kind.equals("home")) {
                    boolean ok=performGlobalAction(kind.equals("back")?GLOBAL_ACTION_BACK:GLOBAL_ACTION_HOME);
                    finish(done,ok?"Uygulandı":"Android işlemi reddetti");
                } else if(kind.equals("tap")||kind.equals("swipe")) {
                    android.util.DisplayMetrics dm=new android.util.DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm);
                    Path path=new Path(); path.moveTo((float)a.getDouble("x")*(dm.widthPixels-1),(float)a.getDouble("y")*(dm.heightPixels-1));
                    if(kind.equals("swipe")) path.lineTo((float)a.getDouble("x2")*(dm.widthPixels-1),(float)a.getDouble("y2")*(dm.heightPixels-1));
                    GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,kind.equals("tap")?80:450)).build();
                    if(!dispatchGesture(g,new GestureResultCallback(){
                        @Override public void onCompleted(GestureDescription d){finish(done,"Dokunma/kaydırma tamamlandı");}
                        @Override public void onCancelled(GestureDescription d){finish(done,"Android hareketi iptal etti");}
                    },main)) finish(done,"Hareket başlatılamadı");
                } else if(kind.equals("type_text")) {
                    AccessibilityNodeInfo root=getRootInActiveWindow();
                    AccessibilityNodeInfo focus=root==null?null:root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                    if(focus==null) throw new Exception("Yazılacak alanı önce seçin");
                    Bundle b=new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,a.getString("text"));
                    boolean ok=focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b); focus.recycle(); if(root!=null)root.recycle();
                    finish(done,ok?"Metin yazıldı":"Alan metin girişine izin vermedi");
                } else if(kind.equals("read_screen")) {
                    StringBuilder text=new StringBuilder(); AccessibilityNodeInfo root=getRootInActiveWindow();
                    read(root,text,0); if(root!=null)root.recycle();
                    finish(done,"Ekran metni (parola alanları hariç):\n"+text);
                } else throw new Exception("Bilinmeyen telefon işlemi");
            } catch(Exception e) {finish(done,"İşlem yapılamadı: "+e.getMessage());}
        },350);
    }
    private void read(AccessibilityNodeInfo node,StringBuilder text,int depth) {
        if(node==null||depth>25||text.length()>10000||node.isPassword()) return;
        if(node.getText()!=null)text.append(node.getText()).append('\n');
        if(node.getContentDescription()!=null)text.append(node.getContentDescription()).append('\n');
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);read(child,text,depth+1);if(child!=null)child.recycle();}
    }
    private void finish(Consumer<String> done,String result) {
        if(!Session.active) return;
        if(panel!=null) add(panel,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,0);
        done.accept(result);
    }
}
