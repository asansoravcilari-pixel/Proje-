package dev.spectre.central;

import android.media.*;
import android.util.Base64;
import java.io.*;
import java.nio.*;
import java.util.Arrays;
import java.util.function.Consumer;

final class Voice {
    private volatile boolean recording;
    private volatile boolean cancelled;
    private Thread worker;
    private volatile AudioTrack track;
    // Permission is requested and checked in MainActivity before the microphone foreground service starts.
    @android.annotation.SuppressLint("MissingPermission")
    void start(Consumer<String> done, Consumer<String> error) {
        if (recording) return;
        recording = true; cancelled = false;
        worker = new Thread(() -> {
            AudioRecord r = null;
            try {
                int size = Math.max(4096, AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT));
                r = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,size);
                if (r.getState()!=AudioRecord.STATE_INITIALIZED) throw new IOException("Mikrofon hazırlanamadı");
                r.startRecording();
                ByteArrayOutputStream pcm = new ByteArrayOutputStream();
                byte[] chunk = new byte[2048];
                while (recording && pcm.size()<16000*2*30) {
                    int n = r.read(chunk,0,Math.min(chunk.length,960000-pcm.size()));
                    if (n<0) throw new IOException("Mikrofon okunamadı");
                    pcm.write(chunk,0,n);
                }
                recording = false;
                byte[] data = pcm.toByteArray();
                if (!cancelled) {
                    if (data.length<3200) throw new IOException("Ses çok kısa");
                    ByteBuffer wav = ByteBuffer.allocate(44+data.length).order(ByteOrder.LITTLE_ENDIAN);
                    wav.put(new byte[]{82,73,70,70}).putInt(36+data.length).put(new byte[]{87,65,86,69,102,109,116,32});
                    wav.putInt(16).putShort((short)1).putShort((short)1).putInt(16000).putInt(32000).putShort((short)2).putShort((short)16);
                    wav.put(new byte[]{100,97,116,97}).putInt(data.length).put(data);
                    done.accept(Base64.encodeToString(wav.array(),Base64.NO_WRAP));
                }
                Arrays.fill(data,(byte)0);
            } catch (Exception e) { if (!cancelled) error.accept("Ses alınamadı: " + e.getMessage()); }
            finally { recording=false; if (r!=null) { try { r.stop(); } catch(Exception ignored) {} r.release(); } }
        }, "voice-capture");
        worker.start();
    }
    void finish() { recording=false; }
    void cancel() {
        cancelled=true; recording=false;
        AudioTrack current = track;
        if(current!=null) { try { current.pause(); current.flush(); } catch(Exception ignored) {} }
    }
    void play(String encoded, Runnable done, Consumer<String> error) {
        cancelled=false;
        new Thread(() -> {
            AudioTrack t = null;
            try {
                byte[] wav=Base64.decode(encoded,Base64.DEFAULT);
                ByteBuffer b=ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN);
                int rate=0, channels=0, bits=0, offset=-1, count=0;
                for(int p=12;p+8<=wav.length;) {
                    int length=b.getInt(p+4);
                    String id=new String(wav,p,4,java.nio.charset.StandardCharsets.US_ASCII);
                    if(id.equals("fmt ") && p+24<=wav.length) {
                        if(b.getShort(p+8)!=1) throw new IOException("PCM ses gerekli");
                        channels=b.getShort(p+10); rate=b.getInt(p+12); bits=b.getShort(p+22);
                    }
                    if(id.equals("data")) { offset=p+8; count=Math.min(length,wav.length-offset); break; }
                    if(length<0 || p+8L+length>wav.length) break;
                    p+=8+length+(length%2);
                }
                if(offset<0||count<=0||rate<=0||channels!=1||bits!=16) throw new IOException("Ses biçimi desteklenmiyor");
                t=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(Math.max(4096,AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
                track=t; t.play();
                int written=0;
                while(written<count && !cancelled) {
                    int n=t.write(wav,offset+written,Math.min(4096,count-written));
                    if(n<=0) throw new IOException("Ses çalınamadı");
                    written+=n;
                }
                while(!cancelled && t.getPlaybackHeadPosition()<written/2) Thread.sleep(20);
                Arrays.fill(wav,(byte)0);
                if(!cancelled) done.run();
            } catch(Exception e) { if(!cancelled) error.accept("Sesli yanıt çalınamadı; işlem iptal edildi"); }
            finally { track=null; if(t!=null) t.release(); }
        },"voice-playback").start();
    }
}
