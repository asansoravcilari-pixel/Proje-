package dev.spectre.central;

import android.content.Context;
import android.graphics.Color;
import android.os.*;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.function.Consumer;

final class Panel extends LinearLayout {
    private final ScreenService screen;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Voice audio=new Voice();
    private final TextView status;
    private final EditText input;
    private final Button send, voice, approve, check;
    private JSONObject proposal;
    private String jobId="";
    private boolean busy=false, recording=false, closed=false, voiceReady=false;
    private int operation=0;
    private final int sessionGeneration;
    Panel(Context c,ScreenService service) {
        super(c); screen=service; sessionGeneration=Session.generation;
        setOrientation(VERTICAL); setPadding(20,20,20,20); setBackgroundColor(Color.rgb(20,26,37));
        TextView title=new TextView(c); title.setText("SPECTRE • açık onaylı oturum"); title.setTextColor(Color.WHITE); title.setTextSize(20); addView(title);
        status=new TextView(c); status.setTextColor(Color.WHITE); status.setText("Komut yazın veya Ses'e basıp konuşun."); status.setTextIsSelectable(true); status.setSaveEnabled(false);
        ScrollView scroll=new ScrollView(c); scroll.addView(status); addView(scroll,new LayoutParams(-1,260));
        input=new EditText(c); input.setHint("Komutunuz"); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY); input.setSaveEnabled(false); input.setMaxLines(3);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        input.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO); addView(input);
        send=button("Yazılı komut gönder",v->requestText());
        voice=button("Sesli komut",v->record());
        approve=button("Bu işlemi onaylıyorum",v->approveText());
        button("İptal",v->cancel());
        check=button("Sunucu sonucunu kontrol et",v->checkJob());
        button("Paneli küçült",v->{close();screen.show();});
        update();
    }
    private Button button(String text,OnClickListener click) {Button b=new Button(getContext());b.setText(text);b.setOnClickListener(click);addView(b);return b;}
    private boolean valid(int op) {return !closed && Session.active && sessionGeneration==Session.generation && operation==op;}
    private void update() {
        boolean pending=proposal!=null;
        send.setEnabled(!busy&&!pending&&!recording);
        approve.setVisibility(pending&&"text".equals(proposal.optString("mode"))?VISIBLE:GONE);
        approve.setEnabled(!busy&&!recording);
        voice.setEnabled(!busy && (!pending||("voice".equals(proposal.optString("mode"))&&voiceReady)));
        voice.setText(recording?"Konuşmayı bitir":pending?"Sesli onay / iptal söyle":"Sesli komut");
        check.setVisibility(jobId.isEmpty()?GONE:VISIBLE); check.setEnabled(!busy&&!recording&&!pending);
    }
    private void requestText() {
        if(input.getText().toString().trim().isEmpty())return;
        try {JSONObject body=new JSONObject().put("mode","text").put("text",input.getText().toString());input.setText("");request("/plan",body,this::planned);}
        catch(Exception e){status.setText(e.getMessage());}
    }
    private void record() {
        if(recording){audio.finish();return;}
        recording=true; update(); status.setText(proposal==null?"Dinleniyor (en fazla 30 sn)…":"Yalnız ‘onaylıyorum’ dersen işlem başlar. Diğer yanıtlar iptal eder.");
        final int op=operation;
        audio.start(encoded->main.post(()->{
            if(!valid(op))return;recording=false;
            try {
                JSONObject body=new JSONObject().put("mode","voice").put("audio",encoded);
                if(proposal==null) request("/plan",body,this::planned);
                else {body.put("id",proposal.getString("id")).put("digest",proposal.getString("digest")); request("/approve",body,this::approved);}
            }catch(Exception e){status.setText(e.getMessage());update();}
        }),error->main.post(()->{if(valid(op)){recording=false;status.setText(error);update();}}));
    }
    private void planned(JSONObject result) {
        if(result.has("id")) {proposal=result;voiceReady=false;status.setText(result.optString("summary")+"\n\n120 saniye içinde onay gerekli.");}
        else status.setText(result.optString("reply",result.toString()));
        if(result.has("audio")) {
            busy=true; update(); final int op=operation;
            audio.play(result.optString("audio"),()->main.post(()->{if(valid(op)){busy=false;voiceReady=true;update();}}),
                error->main.post(()->{if(valid(op)){cancel();status.setText(error);}}));
        }
        update();
    }
    private void approveText() {
        if(proposal==null||!"text".equals(proposal.optString("mode")))return;
        try {request("/approve",new JSONObject().put("id",proposal.getString("id")).put("digest",proposal.getString("digest")).put("mode","text").put("confirmed",true),this::approved);}
        catch(Exception e){status.setText(e.getMessage());}
    }
    private void approved(JSONObject result) {
        proposal=null;voiceReady=false;
        if(result.has("execute")) {
            busy=true;update(); JSONObject action=result.optJSONObject("execute");
            final int op=operation;
            screen.execute(action,text->{
                if(!valid(op))return;
                busy=false;
                if("read_screen".equals(action.optString("kind"))&&text.startsWith("Ekran metni")) {
                    try { request("/screen",new JSONObject().put("ticket",result.optString("screen_ticket")).put("text",text),r->status.setText(text+"\nMerkeze gönderildi; sonraki komutta kullanılabilir.")); }
                    catch(Exception e){status.setText("Ekran gönderilemedi");}
                } else status.setText(text);
                update();
            });
        } else {
            status.setText(result.optString("result",result.toString()));
            if(result.has("job_id"))jobId=result.optString("job_id");
            update();
        }
    }
    private void checkJob(){try{request("/job",new JSONObject().put("id",jobId),r->status.setText(r.toString()));}catch(Exception e){status.setText(e.getMessage());}}
    private void request(String path,JSONObject body,Consumer<JSONObject> success) {
        busy=true;update();final int op=operation;
        Session.io.execute(()->{
            try {JSONObject result=Session.post(path,body);main.post(()->{if(valid(op)){busy=false;success.accept(result);update();}});}
            catch(Exception e){main.post(()->{if(valid(op)){busy=false;proposal=null;voiceReady=false;status.setText("İşlem tamamlanamadı: "+e.getMessage()+"\nOtomatik tekrar yapılmadı.");update();}});}
        });
    }
    private void cancel() {
        operation++;audio.cancel();recording=false;busy=false;voiceReady=false;
        JSONObject old=proposal;proposal=null;
        if(old!=null)Session.io.execute(()->{try{Session.post("/cancel",new JSONObject().put("id",old.getString("id")));}catch(Exception ignored){}});
        status.setText("Bekleyen onay iptal edildi. Önceden onaylanmış/başlamış işlem geri alınmaz.");update();
    }
    void close(){cancel();closed=true;input.setText("");status.setText("");}
}
