package dev.spectre.central;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

final class Session {
    static volatile String url = "", token = "";
    static volatile boolean active = false;
    static volatile int generation = 0;
    static final ExecutorService io = Executors.newSingleThreadExecutor();
    static synchronized void stop() { active = false; generation++; url = ""; token = ""; }
    static JSONObject post(String path, JSONObject data) throws Exception {
        final String endpoint = url, credential = token;
        if (!active || !endpoint.startsWith("https://")) throw new IOException("Önce HTTPS oturumu başlatın");
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint + path).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(110000); c.setInstanceFollowRedirects(false);
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setUseCaches(false);
        c.setRequestProperty("Authorization", "Bearer " + credential);
        c.setRequestProperty("Content-Type", "application/json");
        try {
            byte[] bytes = data.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream s = c.getOutputStream()) { s.write(bytes); }
            int code = c.getResponseCode();
            InputStream in = code == 200 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("Sunucu yanıtı: " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream s = in) {
                byte[] buf = new byte[8192]; int n;
                while ((n=s.read(buf)) != -1) {
                    if (out.size()+n > 12000000) throw new IOException("Yanıt çok büyük");
                    out.write(buf,0,n);
                }
            }
            JSONObject result = new JSONObject(out.toString("UTF-8"));
            if (code != 200) throw new IOException(result.optString("error", "Sunucu hatası"));
            return result;
        } finally { c.disconnect(); }
    }
}
