"""Outbound-only agent. Run as dedicated non-root account. No history files."""
import json
import os
import subprocess
import time
import urllib.request

URL = os.environ.get('CENTRAL_URL', '').rstrip('/')
TOKEN = os.environ.get('AGENT_TOKEN', '')


def post(path, data):
    req = urllib.request.Request(URL+path, data=json.dumps(data).encode(), headers={
        'Authorization':'Bearer '+TOKEN, 'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.load(r)


def execute(command):
    # Capture bounded output in memory; no shell history or inherited control tokens.
    env = {k:v for k,v in os.environ.items() if k in ('PATH','LANG','HOME','TMPDIR')}
    import selectors
    import signal
    p = subprocess.Popen(['/bin/sh','-c',command], stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, env=env, start_new_session=True)
    out = bytearray()
    deadline = time.monotonic()+60
    sel = selectors.DefaultSelector()
    sel.register(p.stdout, selectors.EVENT_READ)
    timed_out = False
    try:
        while sel.get_map():
            if time.monotonic() > deadline:
                timed_out = True
                break
            for key, _ in sel.select(.25):
                chunk = os.read(key.fileobj.fileno(), 4096)
                if not chunk: sel.unregister(key.fileobj)
                else: out.extend(chunk[:max(0,16000-len(out))])
        if timed_out:
            os.killpg(p.pid, signal.SIGKILL)
        p.wait(timeout=2)
    finally:
        if p.poll() is None:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
        sel.close()
        p.stdout.close()
    return json.dumps({'exit_code':p.returncode, 'timeout':timed_out,
                       'output':out.decode(errors='replace')}, ensure_ascii=False)


if __name__ == '__main__':
    if not URL.startswith('https://') or len(TOKEN)<32:
        raise SystemExit('HTTPS CENTRAL_URL ve en az 32 karakter AGENT_TOKEN gerekli')
    while True:
        try:
            job = post('/agent/poll', {})
            if job:
                result = execute(job['action']['command'])
                # Never rerun a command after uncertain transport failure.
                post('/agent/result', {'id':job['id'], 'result':result})
        except Exception:
            pass
        time.sleep(2)
